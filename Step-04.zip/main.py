import hashlib
import datetime

# In-memory user storage (for demonstration)
users = {}

# Route to sign up a new user
def signup(username, password):
    if username in users:
        return {"message": "Username already exists"}, 409

    hashed_password = hashlib.sha256(password.encode()).hexdigest()
    users[username] = hashed_password
    return {"message": "User signed up successfully"}, 201

# Route to sign in
def signin(username, password):
    hashed_password = users.get(username)
    if not hashed_password or hashed_password != hashlib.sha256(password.encode()).hexdigest():
        return {"message": "Invalid username or password"}, 401

    # Simulate token generation (not using jwt library)
    token_data = {'username': username, 'exp': datetime.datetime.utcnow() + datetime.timedelta(minutes=30)}
    token = '.'.join([str(token_data), hashlib.sha256('mysecretkey'.encode()).hexdigest()[:8]])
    return {'token': token}, 200

# Example usage
print(signup('user1', 'password1'))
print(signup('user2', 'password2'))
print(signin('user1', 'password1'))
print(signin('user3', 'password3'))  # This user doesn't exist
print(signin('user2', 'wrongpassword'))  # Incorrect password
