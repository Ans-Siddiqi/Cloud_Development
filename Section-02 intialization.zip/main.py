from fastapi import FastAPI, HTTPException, Depends, status
from pydantic import BaseModel
from typing import List
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from passlib.context import CryptContext
import jwt
from datetime import datetime, timedelta

# Initialize FastAPI
app = FastAPI()

# Define Pydantic models
class Task(BaseModel):
    id: int
    title: str
    description: str
    done: bool

class User(BaseModel):
    username: str
    full_name: str
    email: str
    hashed_password: str

# Sample data (you can replace this with your own data storage)
tasks = [
    Task(id=1, title='Task 1', description='This is task 1', done=False),
    Task(id=2, title='Task 2', description='This is task 2', done=False)
]

# JWT Configurations
SECRET_KEY = "mysecretkey"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30

# Password hashing
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# Sample user data (for demonstration purposes, not storing in a database here)
users_db = {
    "user1": {
        "username": "user1",
        "full_name": "User One",
        "email": "user1@example.com",
        "hashed_password": pwd_context.hash("secret")
    }
}

# Generate JWT Token
def create_access_token(data: dict, expires_delta: timedelta):
    to_encode = data.copy()
    expire = datetime.utcnow() + expires_delta
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

# Dependency to verify JWT token
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

# Verify user credentials
def authenticate_user(username: str, password: str):
    user_data = users_db.get(username)
    if user_data and pwd_context.verify(password, user_data["hashed_password"]):
        return User(**user_data)

# Token endpoint for authentication
@app.post("/token")
async def login_for_access_token(form_data: OAuth2PasswordRequestForm = Depends()):
    user = authenticate_user(form_data.username, form_data.password)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password"
        )
    access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data={"sub": user.username}, expires_delta=access_token_expires
    )
    return {"access_token": access_token, "token_type": "bearer"}

# Protected endpoint requiring authentication
@app.get("/tasks", response_model=List[Task])
async def read_tasks(token: str = Depends(oauth2_scheme)):
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username = payload.get("sub")
        if username:
            return tasks
        else:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid token"
            )
    except jwt.ExpiredSignatureError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token has expired"
        )
    except jwt.JWTError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid token"
        )

# Additional CRUD operations can follow here...
